import java.io.*;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;


public class UniqueState {

	public static class UniqueStateMapper extends Mapper<LongWritable,Text,Text,Text>
	{
		public void map(LongWritable key, Text value, Context context)
		{	    	  
			try{
				String[] str = value.toString().split(",");
				context.write(new Text(str[3]),new Text(str[2]));

			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
	}

	public static class UniqueStateReducer extends Reducer<Text,Text,Text,Text>
	{

		public void reduce(Text key, Iterable<Text> values,Context context) throws IOException, InterruptedException {
			String sum = "(";

			for (Text val : values)
			{
				if(!sum.contains(val.toString()))
				{
					sum= sum+val.toString()+",";
				}
			}	      
			sum=sum+")";
			context.write(key, new Text(sum));

		}
	}
	public static void main(String[] args) throws Exception {

		Configuration conf = new Configuration();
		conf.set("mapreduce.output.textoutputformat.separator", ",");
		Job job = Job.getInstance(conf, "Unique Sataes in Dataset");
		job.setJarByClass(UniqueState.class);
		job.setMapperClass(UniqueStateMapper.class);
		//job.setCombinerClass(ReduceClass.class);
		job.setReducerClass(UniqueStateReducer.class);
		//job.setNumReduceTasks(0);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}